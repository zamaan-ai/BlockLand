// BlockLand Mark 2 — Live Map + Interactions
(() => {
  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

  // ---------- Toast ----------
  const toastEl = $("#toast");
  const notify = (msg, ms = 2800) => {
    toastEl.textContent = msg;
    toastEl.classList.add("show");
    clearTimeout(toastEl._t);
    toastEl._t = setTimeout(() => toastEl.classList.remove("show"), ms);
  };

  // ---------- Sample plots ----------
  const PLOTS = [
    {
      id: "BL-00372",
      title: "2.4 acres near Financial District",
      location: "Nanakramguda, Hyderabad",
      lat: 17.4412,
      lng: 78.3489,
      status: "verified",
      statusLabel: "✓ Government verified",
      area: "2.4 acres",
    },
    {
      id: "BL-00841",
      title: "Greenfield parcel, Sector 79",
      location: "Gurugram",
      lat: 28.4089,
      lng: 77.0677,
      status: "blockchain",
      statusLabel: "◈ Blockchain recorded",
      area: "1.2 acres",
    },
    {
      id: "BL-01120",
      title: "ORR frontage plot",
      location: "Bengaluru",
      lat: 12.9716,
      lng: 77.5946,
      status: "verified",
      statusLabel: "✓ Government verified",
      area: "3.1 acres",
    },
  ];

  const DEFAULT_CENTER = [17.4412, 78.3489]; // Hyderabad Financial District
  const DEFAULT_ZOOM = 13;

  // ---------- Leaflet Map ----------
  let map, markersLayer, routeLayer, activeMarker;
  let streetsLayer, satelliteLayer, hybridLayer;

  function initMap() {
    map = L.map("map", {
      center: DEFAULT_CENTER,
      zoom: DEFAULT_ZOOM,
      zoomControl: true,
    });

    // Base layers — CartoDB (free, no 403) + Esri satellite
    streetsLayer = L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a> &copy; <a href="https://carto.com/">CARTO</a>',
      subdomains: "abcd",
      maxZoom: 20,
    });

    satelliteLayer = L.tileLayer(
      "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
      {
        attribution: "Tiles &copy; Esri",
        maxZoom: 19,
      }
    );

    // Hybrid = satellite + labels
    const labelsLayer = L.tileLayer(
      "https://{s}.basemaps.cartocdn.com/rastertiles/voyager_only_labels/{z}/{x}/{y}{r}.png",
      { subdomains: "abcd", maxZoom: 20, opacity: 0.85 }
    );
    hybridLayer = L.layerGroup([
      L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
        attribution: "Tiles &copy; Esri", maxZoom: 19
      }),
      labelsLayer
    ]);

    streetsLayer.addTo(map);

    // Markers layer
    markersLayer = L.layerGroup().addTo(map);
    routeLayer = L.layerGroup().addTo(map);

    // Add plot markers
    PLOTS.forEach((plot) => {
      const icon = L.divIcon({
        className: "",
        html: `<div class="plot-marker ${plot.status}"><span>${plot.id}</span><small>${plot.statusLabel.replace(/^[^ ]+ /, "")}</small></div>`,
        iconSize: [110, 40],
        iconAnchor: [55, 40],
      });

      const marker = L.marker([plot.lat, plot.lng], { icon }).addTo(markersLayer);

      const popupHtml = `
        <strong>${plot.id}</strong>
        ${plot.title}<br>
        <small>${plot.location} · ${plot.area}</small>
        <div class="status ${plot.status}">${plot.statusLabel}</div>
        <div class="popup-actions">
          <a href="#plot" class="button small">Details</a>
          <button class="button ghost small popup-dir" data-lat="${plot.lat}" data-lng="${plot.lng}">Directions</button>
          <button class="button ghost small popup-sv" data-lat="${plot.lat}" data-lng="${plot.lng}">Street View</button>
        </div>
      `;
      marker.bindPopup(popupHtml);

      marker.on("popupopen", () => {
        // Wire popup buttons after open
        setTimeout(() => {
          $$(".popup-dir").forEach((btn) => {
            btn.onclick = () => {
              openDirectionsTo(+btn.dataset.lat, +btn.dataset.lng);
            };
          });
          $$(".popup-sv").forEach((btn) => {
            btn.onclick = () => openStreetView(+btn.dataset.lat, +btn.dataset.lng);
          });
        }, 50);
      });
    });

    // Basemap switcher
    function setBasemap(name) {
      [streetsLayer, satelliteLayer, hybridLayer].forEach((l) => {
        if (map.hasLayer(l)) map.removeLayer(l);
      });
      if (name === "streets") streetsLayer.addTo(map);
      else if (name === "satellite") satelliteLayer.addTo(map);
      else hybridLayer.addTo(map);
    }
    $$("#basemapTabs button").forEach((btn) => {
      btn.addEventListener("click", () => {
        $$("#basemapTabs button").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        setBasemap(btn.dataset.layer);
      });
    });

    // Toolbar buttons
    $("#btnLocate")?.addEventListener("click", locateUser);
    $("#btnDirections")?.addEventListener("click", () => {
      const panel = $("#directionsPanel");
      panel.hidden = !panel.hidden;
      if (!panel.hidden) $("#dirTo").focus();
    });
    $("#btnStreetView")?.addEventListener("click", () => {
      const c = map.getCenter();
      openStreetView(c.lat, c.lng);
    });
    $("#btnReset")?.addEventListener("click", () => {
      map.setView(DEFAULT_CENTER, DEFAULT_ZOOM);
      routeLayer.clearLayers();
      notify("Map view reset");
    });

    // Map search
    $("#mapSearchBtn")?.addEventListener("click", () => doMapSearch());
    $("#mapSearch")?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") doMapSearch();
    });

    // Directions panel
    $("#closeDirections")?.addEventListener("click", () => {
      $("#directionsPanel").hidden = true;
    });
    $("#getDirectionsBtn")?.addEventListener("click", getRoute);

    // Hero / global search also pans map when relevant
    $("#searchButton")?.addEventListener("click", () => {
      const q = $("#search").value.trim();
      if (q) {
        // Try to find matching plot first
        const match = PLOTS.find(
          (p) =>
            p.id.toLowerCase().includes(q.toLowerCase()) ||
            p.location.toLowerCase().includes(q.toLowerCase()) ||
            p.title.toLowerCase().includes(q.toLowerCase())
        );
        if (match) {
          map.setView([match.lat, match.lng], 15);
          notify(`Showing ${match.id} on map`);
          document.getElementById("explore")?.scrollIntoView({ behavior: "smooth" });
        } else {
          geocodeAndFly(q);
        }
      } else {
        notify("Enter a city, plot ID or landmark");
      }
    });
  }

  // ---------- Geocoding (Nominatim) ----------
  async function geocode(query) {
    const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1`;
    const res = await fetch(url, {
      headers: { "Accept-Language": "en", "User-Agent": "BlockLand-Demo/2.0" },
    });
    const data = await res.json();
    if (data && data[0]) {
      return { lat: +data[0].lat, lng: +data[0].lon, display: data[0].display_name };
    }
    return null;
  }

  async function doMapSearch() {
    const q = $("#mapSearch").value.trim();
    if (!q) return notify("Enter a place to search");
    notify("Searching…");
    try {
      const result = await geocode(q);
      if (result) {
        map.setView([result.lat, result.lng], 15);
        L.popup()
          .setLatLng([result.lat, result.lng])
          .setContent(`<strong>${result.display}</strong>`)
          .openOn(map);
        notify(`Found: ${result.display.split(",")[0]}`);
      } else {
        notify("No results found");
      }
    } catch (err) {
      notify("Search failed — check connection");
      console.error(err);
    }
  }

  async function geocodeAndFly(q) {
    notify("Searching map…");
    try {
      const result = await geocode(q);
      if (result) {
        map.setView([result.lat, result.lng], 14);
        document.getElementById("explore")?.scrollIntoView({ behavior: "smooth" });
        notify(`Showing ${result.display.split(",")[0]}`);
      } else {
        notify(`No map results for “${q}”`);
      }
    } catch {
      notify("Map search unavailable");
    }
  }

  // ---------- Directions (OSRM) ----------
  function openDirectionsTo(lat, lng) {
    const panel = $("#directionsPanel");
    panel.hidden = false;
    $("#dirTo").value = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
    $("#dirFrom").value = "";
    $("#dirFrom").focus();
    map.setView([lat, lng], 14);
  }

  async function getRoute() {
    const fromRaw = $("#dirFrom").value.trim();
    const toRaw = $("#dirTo").value.trim();
    if (!fromRaw || !toRaw) return notify("Enter both start and destination");

    const resultEl = $("#dirResult");
    resultEl.innerHTML = "Calculating route…";

    try {
      let from = parseCoords(fromRaw);
      let to = parseCoords(toRaw);

      if (!from) {
        const g = await geocode(fromRaw);
        if (!g) throw new Error("Could not find starting point");
        from = [g.lat, g.lng];
      }
      if (!to) {
        const g = await geocode(toRaw);
        if (!g) throw new Error("Could not find destination");
        to = [g.lat, g.lng];
      }

      // OSRM public server: lon,lat order
      const url = `https://router.project-osrm.org/route/v1/driving/${from[1]},${from[0]};${to[1]},${to[0]}?overview=full&geometries=geojson&steps=true`;
      const res = await fetch(url);
      const data = await res.json();

      if (data.code !== "Ok" || !data.routes?.[0]) {
        throw new Error("No route found");
      }

      const route = data.routes[0];
      const coords = route.geometry.coordinates.map((c) => [c[1], c[0]]);

      routeLayer.clearLayers();
      const poly = L.polyline(coords, { color: "#1a5f9e", weight: 5, opacity: 0.85 }).addTo(routeLayer);
      map.fitBounds(poly.getBounds(), { padding: [40, 40] });

      // Start / end markers
      L.circleMarker(from, { radius: 7, color: "#0d7a4f", fillColor: "#0d7a4f", fillOpacity: 1 }).addTo(routeLayer);
      L.circleMarker(to, { radius: 7, color: "#c0392b", fillColor: "#c0392b", fillOpacity: 1 }).addTo(routeLayer);

      const distKm = (route.distance / 1000).toFixed(1);
      const mins = Math.round(route.duration / 60);
      let html = `<div class="route-summary">${distKm} km · ~${mins} min drive</div><ol>`;
      const steps = route.legs?.[0]?.steps || [];
      steps.slice(0, 12).forEach((s) => {
        if (s.maneuver?.instruction || s.name) {
          html += `<li>${s.maneuver?.instruction || s.name || "Continue"}</li>`;
        }
      });
      if (steps.length > 12) html += `<li>… +${steps.length - 12} more steps</li>`;
      html += "</ol>";
      resultEl.innerHTML = html;
      notify(`Route ready · ${distKm} km`);
    } catch (err) {
      resultEl.innerHTML = `<span style="color:#c0392b">${err.message || "Route failed"}</span>`;
      notify("Could not calculate route");
      console.error(err);
    }
  }

  function parseCoords(str) {
    const m = str.match(/^\s*(-?\d+\.?\d*)\s*[, ]\s*(-?\d+\.?\d*)\s*$/);
    if (m) return [+m[1], +m[2]];
    return null;
  }

  // ---------- Street View ----------
  function openStreetView(lat, lng) {
    // Opens Google Street View at the location (works without API key)
    const url = `https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=${lat},${lng}`;
    window.open(url, "_blank", "noopener");
    notify("Opening Street View…");
  }

  // ---------- Geolocation ----------
  function locateUser() {
    if (!navigator.geolocation) return notify("Geolocation not supported");
    notify("Locating you…");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        map.setView([latitude, longitude], 15);
        L.circleMarker([latitude, longitude], {
          radius: 8,
          color: "#1a5f9e",
          fillColor: "#3b82f6",
          fillOpacity: 0.9,
        }).addTo(map).bindPopup("You are here").openPopup();
        notify("Location found");
      },
      () => notify("Unable to get your location")
    );
  }

  // ---------- UI: Search tabs, save, modals (from Mark 2) ----------
  $$(".search-tabs button").forEach((btn) => {
    btn.addEventListener("click", () => {
      $$(".search-tabs button").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      const tab = btn.dataset.tab || btn.textContent.trim().toLowerCase();
      $("#search").placeholder = `Search ${tab} by city, ID or landmark`;
    });
  });

  $$(".save-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const on = btn.textContent === "♥";
      btn.textContent = on ? "♡" : "♥";
      notify(on ? "Removed from saved" : "Saved to your list");
    });
  });

  // Directions buttons on land cards
  $$("[data-action='directions']").forEach((btn) => {
    btn.addEventListener("click", () => {
      openDirectionsTo(+btn.dataset.lat, +btn.dataset.lng);
      document.getElementById("explore")?.scrollIntoView({ behavior: "smooth" });
    });
  });

  // Plot page buttons
  $("#plotDirectionsBtn")?.addEventListener("click", () => {
    openDirectionsTo(17.4412, 78.3489);
    document.getElementById("explore")?.scrollIntoView({ behavior: "smooth" });
  });
  $("#plotStreetViewBtn")?.addEventListener("click", () => openStreetView(17.4412, 78.3489));

  // Modals
  const openModal = (id) => {
    const m = $(id);
    if (m) {
      m.hidden = false;
      document.body.style.overflow = "hidden";
    }
  };
  const closeModal = (modal) => {
    modal.hidden = true;
    document.body.style.overflow = "";
  };

  $$(".modal").forEach((modal) => {
    modal.addEventListener("click", (e) => {
      if (e.target.matches("[data-close]") || e.target.classList.contains("modal-backdrop")) {
        closeModal(modal);
      }
    });
  });

  $("#requestVisitBtn")?.addEventListener("click", () => openModal("#visitModal"));
  $("#sidebarVisitBtn")?.addEventListener("click", () => openModal("#visitModal"));
  $$("[data-action='site-visit']").forEach((btn) => {
    btn.addEventListener("click", () => openModal("#visitModal"));
  });
  $("#contactDealerBtn")?.addEventListener("click", () => openModal("#dealerModal"));
  $("#chatDealerBtn")?.addEventListener("click", () => notify("Chat started with Vikram Krishna (demo)"));
  $("#writeReviewBtn")?.addEventListener("click", () => openModal("#reviewModal"));

  $("#visitForm")?.addEventListener("submit", (e) => {
    e.preventDefault();
    closeModal($("#visitModal"));
    notify("Site visit request submitted. Dealer will confirm shortly.");
    e.target.reset();
  });
  $("#dealerForm")?.addEventListener("submit", (e) => {
    e.preventDefault();
    closeModal($("#dealerModal"));
    notify("Enquiry sent to Vikram Krishna. Average response: 38 min.");
    e.target.reset();
  });
  $("#reviewForm")?.addEventListener("submit", (e) => {
    e.preventDefault();
    closeModal($("#reviewModal"));
    notify("Thank you! Your review has been submitted for moderation.");
    e.target.reset();
  });

  $("#walletBtn")?.addEventListener("click", () => {
    notify("Wallet connection is a demo in Mark 2. Full integration comes in later phases.");
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") $$(".modal:not([hidden])").forEach(closeModal);
  });

  // ---------- Boot ----------
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initMap);
  } else {
    initMap();
  }
})();
